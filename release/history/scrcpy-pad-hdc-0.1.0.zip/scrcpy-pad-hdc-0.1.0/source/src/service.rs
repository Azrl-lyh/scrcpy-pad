use std::sync::{Arc, Mutex};

use anyhow::Result;

use crate::backend::HdcInputBackend;
use crate::hdc::Hdc;
use crate::input_capture::{Capture, CaptureEvent};
use crate::keymap::Profile;
use crate::runtime::MappingRuntime;

/// Owns the PC input hook and translates its events into the HDC mapping runtime.
pub struct MappingService {
    runtime: Arc<Mutex<MappingRuntime>>,
    _capture: Capture,
}

impl MappingService {
    pub fn start(serial: impl Into<String>, viewport: (u32, u32)) -> Result<Self> {
        let serial = serial.into();
        let hdc = Hdc::locate()?;
        let backend = Arc::new(HdcInputBackend::new(hdc, serial));
        let runtime = Arc::new(Mutex::new(MappingRuntime::new(
            backend,
            Profile::default(),
            viewport,
        )));

        let (tx, rx) = std::sync::mpsc::channel::<CaptureEvent>();
        let capture = Capture::start(tx)?;

        let worker_runtime = runtime.clone();
        std::thread::spawn(move || {
            while let Ok(event) = rx.recv() {
                if let CaptureEvent::Button { code, pressed } = event {
                    let mut runtime = worker_runtime.lock().unwrap();
                    runtime.handle_key_event(code, pressed, &[]);
                }
            }
        });

        Ok(Self {
            runtime,
            _capture: capture,
        })
    }

    pub fn runtime(&self) -> Arc<Mutex<MappingRuntime>> {
        self.runtime.clone()
    }
}
