# scrcpy-pad HarmonyOS HDC client

This directory is the PC-side HarmonyOS product line. It is independent from:

- the original Windows/Linux scrcpy-pad desktop app;
- `harmonyos/`, which is only an optional on-device ArkTS companion for Bluetooth keyboard mapping.

## Why this exists

HarmonyOS NEXT/HarmonyOS 6 does not run the Android `scrcpy-server.apk`. The replacement path is:

```text
scrcpy-pad PC client
        |
        | HDC: shell / fport / file
        v
HarmonyOS device
  - uinput: touch/key/mouse injection
  - uitest screenCap: screen snapshots
```

OpenHarmony's `uinput` tool supports independent touch events:

- `uinput -T -d x y`
- `uinput -T -m x1 y1 x2 y2 [keep_ms] [smooth_ms]`
- `uinput -T -u x y`

It also supports keyboard and mouse including buttons and scroll:

- `uinput -K ...`
- `uinput -M ...`

`uitest screenCap -p /data/local/tmp/file.png` captures the current screen.

## Current CLI probe

Build:

```powershell
cd D:\GitHub\scrcpy-pad-developing-yaml\harmonyos-pc
cargo build
```

Run:

```powershell
cargo run -- devices
cargo run -- doctor
cargo run -- tap <serial> 540 1200
cargo run -- swipe <serial> 900 1600 300 1600 300
cargo run -- capture <serial> screen.png
```

`doctor` checks whether the connected device exposes:

- `uinput`
- `uitest`
- `snapshot_display`
- HarmonyOS version and API level

The next layer will replace the CLI probe with a long-running protocol and the existing scrcpy-pad UI.

## GUI Probe

Build and run:

```powershell
.\build.ps1
.\target\release\hdc-pad-gui.exe
```

The GUI currently provides:

- HDC device discovery
- device selection
- manual screenshot capture through `uitest screenCap`
- tap, swipe and hold injection tests through `uinput`
- future integration point for the existing scrcpy-pad keymap, wheel and FPS UI
